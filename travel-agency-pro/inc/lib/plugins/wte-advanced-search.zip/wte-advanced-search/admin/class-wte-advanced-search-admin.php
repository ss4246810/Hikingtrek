<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://www.wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Advanced_Search
 * @subpackage Wte_Advanced_Search/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wte_Advanced_Search
 * @subpackage Wte_Advanced_Search/admin
 * @author     WP Travel Engine <wptravelengine.com>
 */
class Wte_Advanced_Search_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Advanced_Search_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Advanced_Search_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wte-advanced-search-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Advanced_Search_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Advanced_Search_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wte-advanced-search-admin.js', array( 'jquery' ), $this->version, false );

	}

	function wte_advanced_search_page()
	{ ?> 
		<div class="wp_travel_engine_settings_pages">
		<label for="wp_travel_engine_settings[pages][enquiry]"><?php _e( 'Search Result Page:','wp-travel-engine-trip-search' ); ?><span class="required">*</span></label>
			<?php
			$options = get_option( 'wp_travel_engine_settings' );
			$search = isset($options['pages']['search']) ? esc_attr($options['pages']['search']) : '';
		    wp_dropdown_pages(
		        array(
		             'name' => 'wp_travel_engine_settings[pages][search]',
		             'echo' => 1,
		             'show_option_none' => __( '&mdash; Select &mdash;', 'wp-travel-engine-trip-search' ),
		             'option_none_value' => '0',
		             'selected' => $search,
		        )
		    );
		    ?>
	    <div class="settings-note"><?php _e('This is the search result page where [WTE_Trip_Search] shortcode is required.','wp-travel-engine-trip-search');?></div>
	</div>
	<?php
	}
}
