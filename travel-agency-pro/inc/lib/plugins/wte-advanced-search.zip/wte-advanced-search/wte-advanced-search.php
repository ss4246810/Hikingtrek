<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link       		  https://www.wptravelengine.com
 * @since             1.0.0
 * @package           Wte_Advanced_Search
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine Trip Search 
 * Plugin URI:        https://wptravelengine.com
 * Description:       Add an advanced trip search feature to WP Travel Engine. 
 * Version:           1.0.4
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wp-travel-engine-trip-search
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'WTE_ADVANCED_SEARCH_BASE_PATH', dirname( __FILE__ ) );
define( 'WTE_ADVANCED_SEARCH_TEMPLATE_PATH', WTE_ADVANCED_SEARCH_BASE_PATH.'/includes/templates' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wte-advanced-search-activator.php
 */
function activate_wte_advanced_search() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wte-advanced-search-activator.php';
	Wte_Advanced_Search_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wte-advanced-search-deactivator.php
 */
function deactivate_wte_advanced_search() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wte-advanced-search-deactivator.php';
	Wte_Advanced_Search_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wte_advanced_search' );
register_deactivation_hook( __FILE__, 'deactivate_wte_advanced_search' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wte-advanced-search.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wte_advanced_search() {

	$plugin = new Wte_Advanced_Search();
	$plugin->run();

}
run_wte_advanced_search();
