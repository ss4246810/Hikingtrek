<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://www.wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Advanced_Search
 * @subpackage Wte_Advanced_Search/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
