<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://www.wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Advanced_Search
 * @subpackage Wte_Advanced_Search/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wte_Advanced_Search
 * @subpackage Wte_Advanced_Search/public
 * @author     WP Travel Engine <wptravelengine.com>
 */
class Wte_Advanced_Search_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Advanced_Search_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Advanced_Search_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wte-advanced-search-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Advanced_Search_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Advanced_Search_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( 'wte-advanced-search-public', plugin_dir_url( __FILE__ ) . 'js/wte-advanced-search-publ.js', array( 'jquery', 'jquery-ui' ), $this->version, true );
    	wp_enqueue_script( 'jquery-ui-slider' );    
	}

	//Add body class in search page
	function wpte_search_body_classes( $classes ) {
	 	global $post;
	 	$options = get_option( 'wp_travel_engine_settings' );
		$search = isset($options['pages']['search']) ? esc_attr($options['pages']['search']) : '';
	 	if( $post->ID == $search )
	 	{
	    	$classes[] = 'trip-search-result';
	 	}
	    return $classes;
	}
}
