jQuery(document).ready(function($){ 
	$( document ).on( 'click', '.trip-duration', function (e) {
		$(this).children('.search-duration').toggleClass('show');
	});
	$( document ).on( 'click', '.trip-cost', function (e) {
		$(this).children('.search-cost').toggleClass('show');
	});
});
