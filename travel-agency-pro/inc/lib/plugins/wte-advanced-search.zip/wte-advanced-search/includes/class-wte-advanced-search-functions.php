<?php

/**
* Basic functions
*/
class Wte_Advanced_Search_Functions
{
	function Wte_advanced_search_nav($query, $pages = '', $range = 4) {
        global $wp_query;
        $pages = $query->max_num_pages;
        $paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 0;
        $showitems = get_option( 'posts_per_page' );
        if(!$pages)
        {
         $pages = 1;
        }
         
        if(1 != $pages)
        {
            echo '<nav class="navigation pagination" style="clear:both;" role="navigation"><h2 class="screen-reader-text">Posts navigation</h2><div class="nav-links">';
            if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<a href='".get_pagenum_link(1)."'>".__('First','wp-travel-engine-trip-search')."</a>";
            if($paged > 1 && $showitems < $pages) echo "<a class='prev page-numbers' href='".get_pagenum_link($paged - 1)."'>".__('Previous','wp-travel-engine-trip-search')."</a>";

            for ($i=1; $i <= $pages; $i++)
            {
            if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
            {
            echo ($paged == $i)? '<span aria-current="page" class="page-numbers current"><span class="meta-nav screen-reader-text"></span>'.$i."</span>":"<a class='page-numbers' href='".get_pagenum_link($i)."' class=\"inactive\">".$i."</a>";
            }
            }

            if ($paged < $pages && $showitems < $pages) echo "<a class='next page-numbers' href=\"".get_pagenum_link($paged + 1)."\">".__('Next','wp-travel-engine-trip-search')."</a>"; 
            if ($paged < $pages-1 && $paged+$range-1 < $pages && $showitems < $pages) echo "<a href='".get_pagenum_link($pages)."'>".__('Last','wp-travel-engine-trip-search')."</a>";
            echo "</div></nav>\n";
        }
    }
}