<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://www.wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Advanced_Search
 * @subpackage Wte_Advanced_Search/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wte_Advanced_Search
 * @subpackage Wte_Advanced_Search/includes
 * @author     WP Travel Engine <wptravelengine.com>
 */
class Wte_Advanced_Search_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
