<?php
/**
 * This class defines all code necessary to run for frontend section.
 *
 * @since      1.0.0
 * @package    Wte_Advanced_Search
 * @subpackage Wte_Advanced_Search/includes
 * @author     WP Travel Engine <wptravelengine.com>
 */
class Wte_Advanced_Search_Template {

	function __construct()
	{
		add_shortcode( 'Wte_Advanced_Search_Form', array($this, 'wte_advanced_search_form' ) );
		add_filter( 'template_redirect', array( $this, 'wte_advance_search_shortcode' ) );
		add_action( 'wp_ajax_wte_show_ajax_result', array( $this, 'wte_show_ajax_result' ) );
		add_action( 'wp_ajax_nopriv_wte_show_ajax_result', array( $this, 'wte_show_ajax_result' ) );

		add_action( 'wp_ajax_wte_show_ajax_result_load', array( $this, 'wte_show_ajax_result_load' ) );
		add_action( 'wp_ajax_nopriv_wte_show_ajax_result_load', array( $this, 'wte_show_ajax_result_load' ) );

		add_action( 'wte_advanced_search', array($this,'wte_advanced_search_form_template') );
		add_action( 'wp_ajax_wte_show_ajax_archives_result', array( $this, 'wte_show_ajax_archives_result' ) );
		add_action( 'wp_ajax_nopriv_wte_show_ajax_archives_result', array( $this, 'wte_show_ajax_archives_result' ) );
	}

	//Search form template for WP Travel Engine Archive
	public function wte_advanced_search_form_template() {
		$options = get_option( 'wp_travel_engine_settings', array() );
		if( isset( $options['pages']['search'] ) && $options['pages']['search']!='' )
		{
			ob_start();
			$pid = $options['pages']['search'];
			$nonce = wp_create_nonce('search-nonce');
			?>
					<div class='advanced-search-wrapper'>
							<input type="hidden" id="search-nonce" name="search-nonce" value="<?php echo $nonce;?>">
							<?php 
							$categories = get_categories('taxonomy=trip_types');
				  
							$select = "<div class='advanced-search-field trip-type'><ul>";
							  
							foreach($categories as $category){
							    if($category->count > 0){
							        $select.= "<li><label><input type='checkbox' name='cat' class='cat' value='".$category->slug."'><span>".$category->name."</span></label><span class='count'>".$category->category_count."</span></li>";
							    }
							}
							  
							$select.= "</ul></div>";
							  
							echo $select;


							global $post;
							$wte_doc_tax_post_args = array(
				    			'post_type' => 'trip', // Your Post type Name that You Registered
				    			'posts_per_page' => -1,
				    			'order' => 'ASC',
							);
							$wte_doc_tax_post_qry = new WP_Query($wte_doc_tax_post_args);
							$max_cost = 0; $max_duration = 0;
					    	if($wte_doc_tax_post_qry->have_posts()) :
					       		while($wte_doc_tax_post_qry->have_posts()) :
				            		$wte_doc_tax_post_qry->the_post(); 
									$wp_travel_engine_setting = get_post_meta( $post->ID,'wp_travel_engine_setting',true );
			        				$cost = isset( $wp_travel_engine_setting['trip_price'] ) ? $wp_travel_engine_setting['trip_price']: '';
									$prev_cost = isset($wp_travel_engine_setting['trip_prev_price']) ? $wp_travel_engine_setting['trip_prev_price']: '';
			                        if( $cost!='' && isset($wp_travel_engine_setting['sale']) )
			                        {
			                        	$comp_cost = $prev_cost;
			                        }
			                        else{
			                        	$comp_cost = $wp_travel_engine_setting['trip_prev_price'];
			                        }

									if( $max_cost < $comp_cost )
									{
										$max_cost = $comp_cost;
									}
									if( $max_duration < $wp_travel_engine_setting['trip_duration'] )
									{
										$max_duration = $wp_travel_engine_setting['trip_duration'];
									}
								endwhile;
							endif;
							
							echo '<div class="advanced-search-field search-cost"><h3>'.__('Price','wp-travel-engine-trip-search').'</h3><div id="cost-slider-range"></div><div class="cost-slider-value"><span id="min-cost" class="min-cost" name="min-cost">0</span><span class="max-cost" id="max-cost" name="max-cost">"'.$max_cost.'"</span></div></div>';

								echo '<div class="advanced-search-field search-duration"><h3>'.__('Duration','wp-travel-engine-trip-search').'</h3><div id="duration-slider-range"></div><div class="duration-slider-value"><span id="min-duration" class="min-duration" name="min-duration">0</span><span class="id="max-duration"" id="max-duration" name="max-duration">"'.$max_duration.'"</span></div></div>';


							$categories = get_categories('taxonomy=activities');
				  
							$select = "<div class='advanced-search-field activities'><ul>";
							  
							foreach($categories as $category){
							    if($category->count > 0){
							        $select.= "<li><label><input type='checkbox' name='activities' class='input-activities' value='".$category->slug."'><span>".$category->name."</span></label><span class='count'>".$category->category_count."</span></li>";
							    }
							}
							  
							$select.= "</ul></div>";
							  
							echo $select;


							$categories = get_categories('taxonomy=destination');
				  
							$select = "<div class='advanced-search-field destination'><ul>";
							  
							foreach($categories as $category){
							    if($category->count > 0){
							        $select.= "<li><label><input type='checkbox' name='destination' class='input-destination' value='".$category->slug."'><span>".$category->name."</span></label><span class='count'>".$category->category_count."</span></li>";
							    }
							}
							  
							$select.= "</ul></div>";
							  
							echo $select;
							?>
					</div>
			</form>
	<?php
			
			echo 
			'<script>
			jQuery(document).ready(function($){
				var choices = {};
				$( "#duration-slider-range" ).slider({
					range: true,
					min: 0,
					max: '.$max_duration.',
					values: [ 0 , '.$max_duration.' ],
					slide: function( event, ui ) {
		                $("#min-duration").val(ui.values[0]);
					    $("#max-duration").val(ui.values[1]);
		            },
					stop: function( event, ui ) {
						$( "#duration-slider-range" ).slider( "disable" );
					    maxdur = ui.values[1];
					    mindur = ui.values[0];
					    $("#min-duration").val(ui.values[0]);
					    $("#max-duration").val(ui.values[1]);
					    mincost = $("#min-cost").val();
						maxcost = $("#max-cost").val();
					    nonce = $("#search-nonce").val();
						$(".advanced-search-field input[type=checkbox]").each(function() {
							if($(this).is(":checked"))
	    					{
				                if (!choices.hasOwnProperty(this.name)) {
			                    	choices[this.name] = [];
				                }
			                    choices[this.name].push(this.value);
				            }
			            });

			            jQuery.ajax({
					        type : "post",
					        url : WTEAjaxData.ajaxurl,
					        data : {action: "wte_show_ajax_result", maxcost : maxcost, mincost : mincost, maxdur : maxdur, mindur : mindur, result : choices, nonce:nonce},
					        beforeSend: function(){
			                	$("#loader").fadeIn(500);
			            	},
				            success: function(response){
				            	$(".wte-advanced-search-wrap").remove();
				            	$(".advanced-search-wrapper .page-navigation").remove();
				            	$(".advanced-search-wrapper").append(response);
								$( "#duration-slider-range" ).slider( "enable" );
				            },
				            complete: function(){
			                	$("#loader").fadeOut(500);             
			            	}
				    	});
					}
				});

				$( "#cost-slider-range" ).slider({
					range: true,
					min: 0,
					max: '.$max_cost.',
					values: [ 0, '.$max_cost.' ],
					slide: function( event, ui ) {
		                $("#min-cost").val(ui.values[0]);
					    $("#max-cost").val(ui.values[1]);
		            },
					stop: function( event, ui ) {
						$( "#cost-slider-range" ).slider( "disable" );
						maxcost = ui.values[1];
					    mincost = ui.values[0];
					    $("#min-cost").val(ui.values[0]);
					    $("#max-cost").val(ui.values[1]);
					    maxdur = $("#max-duration").val();
					    mindur = $("#min-duration").val();
					    nonce = $("#search-nonce").val();
						$(".advanced-search-field input[type=checkbox]").each(function() {
							if($(this).is(":checked"))
	    					{
				                if (!choices.hasOwnProperty(this.name)) {
			                    	choices[this.name] = [];
				                }
			                    choices[this.name].push(this.value);
				            }
			            });

			            jQuery.ajax({
					        type : "post",
					        url : WTEAjaxData.ajaxurl,
					        data : {action: "wte_show_ajax_result", maxcost : maxcost, mincost : mincost, maxdur : maxdur, mindur : mindur, result : choices, nonce:nonce},
					        beforeSend: function(){
			                	$("#loader").fadeIn(500);
			            	},
				            success: function(response){
				            	$(".wte-advanced-search-wrap").remove();
				            	$(".advanced-search-wrapper .page-navigation").remove();
				            	$(".advanced-search-wrapper").append(response);
								$( "#cost-slider-range" ).slider( "enable" );
				            },
				            complete: function(){
			                	$("#loader").fadeOut(500);             
			            	}
				    	});
					}
				});

				
				$("body").on("change",".advanced-search-field input[type=checkbox]", function(){
				    mincost = $("#min-cost").val();
					maxcost = $("#max-cost").val();
					mindur = $("#min-duration").val();
					maxdur = $("#max-duration").val();
					$(".advanced-search-field input[type=checkbox]").each(function() {
						if($(this).is(":checked"))
    					{
			                if (!choices.hasOwnProperty(this.name)) {
		                    	choices[this.name] = [];
			                }
			                var idx = $.inArray(this.value, choices[this.name]);
							if (idx == -1) {
		                    	choices[this.name].push(this.value);
		                    }
			            }
		            });
		            value = this.value;
					if(!$(this).is(":checked"))
    				{
						var idx = choices[this.name].indexOf(value);
				        if (idx > -1) {
            				choices[this.name].splice(idx, 1);
            			}
	                }
					nonce = $("#search-nonce").val();
				    jQuery.ajax({
				        type : "post",
				        url : WTEAjaxData.ajaxurl,
				        data : {action: "wte_show_ajax_result", maxcost : maxcost, mincost : mincost, maxdur : maxdur, mindur : mindur, result : choices, nonce:nonce},
				        beforeSend: function(){
		                	$("#loader").fadeIn(500);
		            	},
			            success: function(response){
			            	$(".wte-advanced-search-wrap").remove();
			            	$(".advanced-search-wrapper .page-navigation, .advanced-search-wrapper .foundPosts").remove();
			            	$(".advanced-search-wrapper").append(response);
			            },
			            complete: function(){
		                	$("#loader").fadeOut(500);             
		            	}
				    });
				     
			   	});
			});
			</script>';
			$output = ob_get_contents();
			ob_end_clean();
			echo $output;
			exit;	
		}
	}
	/**
	 *
	 * Search form.
	 *
	 * @since    1.0.0
	 */
	public function wte_advanced_search_form() { 
		$options = get_option( 'wp_travel_engine_settings', array() );
		if( isset( $options['pages']['search'] ) && $options['pages']['search']!='' )
		{
			ob_start();
			$pid = $options['pages']['search'];
			$nonce = wp_create_nonce('search-nonce');
			
			global $post;
			$wte_doc_tax_post_args = array(
    			'post_type' => 'trip', // Your Post type Name that You Registered
    			'posts_per_page' => -1,
    			'order' => 'ASC',
			);
			$wte_doc_tax_post_qry = new WP_Query($wte_doc_tax_post_args);
			$max_cost = 0; $max_duration = 0;
	    	if($wte_doc_tax_post_qry->have_posts()) :
	       		while($wte_doc_tax_post_qry->have_posts()) :
            		$wte_doc_tax_post_qry->the_post(); 
					$wp_travel_engine_setting = get_post_meta( $post->ID,'wp_travel_engine_setting',true );
    				$cost = isset( $wp_travel_engine_setting['trip_price'] ) ? $wp_travel_engine_setting['trip_price']: '';
					$prev_cost = isset($wp_travel_engine_setting['trip_prev_price']) ? $wp_travel_engine_setting['trip_prev_price']: '';
					$wp_travel_engine_setting['trip_duration'] = isset($wp_travel_engine_setting['trip_duration']) ? $wp_travel_engine_setting['trip_duration']: '';
                    if( $cost!='' && isset($wp_travel_engine_setting['sale']) )
                    {
                    	$comp_cost = $cost;
                    }
                    else{
                    	$comp_cost = $prev_cost;
                    }

					if( $max_cost < $comp_cost )
					{
						$max_cost = $comp_cost;
					}
					if( $max_duration < $wp_travel_engine_setting['trip_duration'] )
					{
						$max_duration = $wp_travel_engine_setting['trip_duration'];
					}
				endwhile;
			endif;
			?>
			<h3><?php $search_title = apply_filters( 'wte_advanced_search_title','Search for a trip' ); echo $search_title; ?></h3>
			<form method="get" action='<?php echo esc_url(get_permalink($pid));?>' id="wte-advanced-search-form-shortcode">
			<div class="class-wte-advanced-search-wrapper">
	            <input type="hidden" name="search-nonce" value="<?php echo $nonce;?>">
	            <?php 
	            $categories = get_categories('taxonomy=destination');

	            $select = "<div class='advanced-search-field trip-destination'><h3>".__('Destination','wp-travel-engine-trip-search')."</h3><div class='custom-select'><select name='destination' id='destination' class='postform'>";
	            $select.= "<option value='-1'>Destination</option>";
	              
	            foreach($categories as $category){
	                if($category->count > 0){
	                    $select.= "<option value='".$category->slug."'>".$category->name."</option>";
	                }
	            }
	              
	            $select.= "</select></div></div>";
	              
	            echo $select;

	            $categories = get_categories('taxonomy=activities');

	            $select = "<div class='advanced-search-field trip-activities'><h3>".__('Activities','wp-travel-engine-trip-search')."</h3><div class='custom-select'><select name='activities' id='activities' class='postform'>";
	            $select.= "<option value='-1'>Activities</option>";
	              
	            foreach($categories as $category){
	                if($category->count > 0){
	                    $select.= "<option value='".$category->slug."'>".$category->name."</option>";
	                }
	            }
	              
	            $select.= "</select></div></div>";
	            echo $select;

	            $select = "<div class='advanced-search-field trip-duration'>";
	            $select .='<h3>'.__('Duration','wp-travel-engine-trip-search').'</h3>';
	            $select .='<strong>'.__('Duration','wp-travel-engine-trip-search').'</strong>';
	            $select .= '<div class="advanced-search-field search-dur"><div id="duration-slider-range"></div><div class="duration-slider-value"><span id="min-duration" class="min-duration" name="min-duration">0</span><span class="max-duration" id="max-duration" name="max-duration">'.$max_duration.'</span></div></div>';
	            $select .= '<input type="hidden" id="min-duration-value" value="0" name="min-duration"><input type="hidden" id="max-duration-value" name="max-duration" value="'.$max_duration.'">';

	            $select.= "</div>";
	            echo $select;

	            $select  ='<div class="advanced-search-field trip-cost"><h3>'.__('Budget','wp-travel-engine-trip-search')."</h3>";
	            $select .='<strong>'.__('Budget','wp-travel-engine-trip-search').'</strong>';
	            $select .= '<div class="advanced-search-field search-price"><div id="cost-slider-range"></div><div class="cost-slider-value"><span class="min-cost" id="min-cost" name="min-cost">0</span><span class="max-cost" id="max-cost" name="max-cost">'.$max_cost.'</span></div></div></div>';
	            $select .= '<input type="hidden" id="min-cost-value" name="min-cost" value="0"><input type="hidden" id="max-cost-value" name="max-cost" value="'.$max_cost.'">';

	            echo $select;
	            ?>

	            <div class='advanced-search-field-submit'><input type="submit" name="search" value="<?php $search = apply_filters('wte_search_label', 'Search'); _e( $search ,'wp-travel-engine-trip-search');?>"></div>
        	</div>
        </form>
	<?php
			
			
			echo 
			'<script>
			jQuery(document).ready(function($){
				var choices = {};
				$( "#duration-slider-range" ).slider({
					range: true,
					min: 0,
					max: '.$max_duration.',
					values: [ 0 , '.$max_duration.' ],
					slide: function( event, ui ) {
		                $("#min-duration").text(ui.values[0]);
					    $("#max-duration").text(ui.values[1]);
					    $("#min-duration-value").val(ui.values[0]);
					    $("#max-duration-value").val(ui.values[1]);
		            },
				});

				$( "#cost-slider-range" ).slider({
					range: true,
					min: 0,
					max: '.$max_cost.',
					values: [ 0, '.$max_cost.' ],
					slide: function( event, ui ) {
		                $("#min-cost").text(ui.values[0]);
					    $("#max-cost").text(ui.values[1]);
					    $("#min-cost-value").val(ui.values[0]);
					    $("#max-cost-value").val(ui.values[1]);
		            },
				});
				$( document ).on( "click", ".trip-duration strong", function (e) {
					$(this).siblings(".search-dur").toggleClass("show");
				});
				$( document ).on( "click", ".trip-cost strong", function (e) {
					$(this).siblings(".search-price").toggleClass("show");
				});
			});</script>';

			$output = ob_get_contents();
			ob_end_clean();
			echo $output;
		}
	}

	/**
	 *
	 * Search result.
	 *
	 * @since    1.0.0
	 */
	function wte_advance_search_shortcode()
	{
		global $post;
		$options = get_option( 'wp_travel_engine_settings', array() );
		if(!isset($options['pages']['search']))
			return;

		$pid = $options['pages']['search'];

		if (!is_object($post))
		return;

		if( $post->ID != $pid)
		return;	
		
		if ( $theme_file = locate_template( array ( 'trip-results.php' ) ) ) {
	        $template_path = $theme_file;
        } else {
            $template_path = WTE_ADVANCED_SEARCH_TEMPLATE_PATH . '/trip-results.php';
        }
		ob_start();
	    load_template( $template_path );
	    $obj = new WTE_Show_Trip_Results;
	    $obj->wte_show_result($_GET);
	    $output = ob_get_clean();
	 	echo $output;
		exit();
	}

	function wte_show_ajax_result()
	{
		$nonce = wp_create_nonce('search-nonce');
		if(isset($_REQUEST['nonce']) && wp_verify_nonce( $_REQUEST['nonce'], "search-nonce" ) )
		{			
  			$msg = __("No results found!","wp-travel-engine-trip-search");

			if( !empty( $_REQUEST["result"]["cat"] ) ) {
				foreach ( $_REQUEST["result"]["cat"] as $key => $value ) {
					$term = get_term_by('slug', $value, 'trip_types');
			    	$cat[] = $term->term_id;
				}
			}

			if( !empty( $_REQUEST["result"]["budget"] ) ) {
			    $budget = $_REQUEST["result"]["budget"];
			}

			if( !empty( $_REQUEST["result"]["activities"] ) ) {
			    foreach ( $_REQUEST["result"]["activities"] as $key => $value ) {
					$term = get_term_by('slug', $value, 'activities');
			    	$activities[] = $term->term_id;
				}
			}

			if( !empty( $_REQUEST["result"]["destination"] ) ) {
			    foreach ( $_REQUEST["result"]["destination"] as $key => $value ) {
					$term = get_term_by('slug', $value, 'destination');
			    	$destination[] = $term->term_id;
				}
			}

			if( !empty( $_REQUEST["result"]["duration"] ) ) {
			    $duration = $_REQUEST["result"]["duration"];
			}

			if( !empty( $_REQUEST["cost"] ) ) {
			    $cost = $_REQUEST["cost"];
			}
            $default_posts_per_page = get_option( 'posts_per_page' );

			$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;

			// Query arguments.
			$args = array(
			            'post_type'      				=> 'trip',
			            'posts_per_page' 				=> $default_posts_per_page,
			            'wpse_search_or_tax_query'      => true,
			        );

			$taxquery = array();
  			
			if( !empty( $_REQUEST["result"]["cat"] ) && $_REQUEST["result"]["cat"]!= '-1'  ){
			    array_push($taxquery,array(
			            'taxonomy' => 'trip_types',
			            'field'    => 'term_id',
			            'terms'    => $cat,
			            'include_children' => false,
			        ));
			}

			if(!empty($_REQUEST["result"]["activities"]) && $_REQUEST["result"]["activities"]!='-1' ) {
			    array_push($taxquery,array(
			            'taxonomy' 	=> 'activities',
			            'field' 	=> 'term_id',
			            'terms' 	=> $activities,
			            'include_children' => false,
			        ));
			}

			if(!empty($_REQUEST["result"]["destination"]) && $_REQUEST["result"]["destination"]!='-1' ) {
			    array_push($taxquery,array(
			            'taxonomy' 	=> 'destination',
			            'field' 	=> 'term_id',
			            'terms' 	=> $destination,
			            'include_children' => false,
			        ));
			}

			if(!empty($taxquery)){
				$args['tax_query']['relation'] = 'AND';
				$args['tax_query'] = $taxquery;
			}
			$meta_query = array();

			$start_cost = (int)$_REQUEST['mincost'];
			$end_cost = (int)$_REQUEST['maxcost'];
			$meta_query[] = array(
			    array(
		            'key' => 'wp_travel_engine_setting_trip_price',
		            'value' => array($start_cost,$end_cost),
		            'compare' => 'BETWEEN',
					'type'	=> 'NUMERIC'

		        )
			);
		    
			$start_dur = (int)$_REQUEST['mindur'];
			$end_dur = (int)$_REQUEST['maxdur'];
			$meta_query[] = array(
			    array(
		            'key' => 'wp_travel_engine_setting_trip_duration',
		            'value' => array($start_dur,$end_dur),
		            'compare' => 'BETWEEN',
					'type'	=> 'NUMERIC'

		        )
			);

			if(!empty($meta_query)){
				 	$args['meta_query'] = $meta_query;
			}
		    $query = new WP_Query($args);
		    ob_start();
			   	echo '<div class="wte-advanced-search-wrap">';
			   	echo ($query->found_posts > 0) ? '<h3 class="foundPosts">' . $query->found_posts. ' trip(s) found:'.'</h3>' : '<h3 class="foundPosts">'.apply_filters( 'no_result_found_message',$msg ).'</h3>';
			   	echo '<div class="grid">';
			    	global $post;
					while ( $query->have_posts() ) {
						$query->the_post(); 
		    			$wp_travel_engine_setting = get_post_meta( $post->ID,'wp_travel_engine_setting',true );
                        $wp_travel_engine_setting_option_setting = get_option( 'wp_travel_engine_settings', true );
		    			?>
						<div class="col">
                    		<div class="img-holder">
				                <a href="<?php the_permalink(); ?>" class="trip-post-thumbnail">
									<?php 
									$feat_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'trip-thumb-size' ); 
									if( isset($feat_image_url[0]) && $feat_image_url[0]!='' )
									{ ?>
        								<img src="<?php echo esc_url( $feat_image_url[0] );?>">
        
        							<?php }  else{
                                               echo '<img src="'.esc_url(  WP_TRAVEL_ENGINE_IMG_URL . '/public/css/images/trip-listing-fallback.jpg' ).'">';
                                            }?>
								</a>
								   <?php
                                    $code = 'USD';
                                    if( isset($wp_travel_engine_setting_option_setting['currency_code']) && $wp_travel_engine_setting_option_setting['currency_code']!='')
                                    {
                                        $code = esc_attr( $wp_travel_engine_setting_option_setting['currency_code'] );
                                    }
                                    $obj = new Wp_Travel_Engine_Functions();
                                    $currency = $obj->wp_travel_engine_currencies_symbol( $code );
                                    $cost = isset( $wp_travel_engine_setting['trip_price'] ) ? $wp_travel_engine_setting['trip_price']: '';
                                    
                                    $prev_cost = isset( $wp_travel_engine_setting['trip_prev_price'] ) ? $wp_travel_engine_setting['trip_prev_price']: '';

                                        $code = 'USD';
                                        if( isset( $wp_travel_engine_setting_option_setting['currency_code'] ) && $wp_travel_engine_setting_option_setting['currency_code']!= '' )
                                        {
                                            $code = $wp_travel_engine_setting_option_setting['currency_code'];
                                        } 
                                        $obj = new Wp_Travel_Engine_Functions();
                                        $currency = $obj->wp_travel_engine_currencies_symbol( $code );
                                        $prev_cost = isset($wp_travel_engine_setting['trip_prev_price']) ? $wp_travel_engine_setting['trip_prev_price']: '';
                                        if( $cost!='' && isset($wp_travel_engine_setting['sale']) )
                                        {
                                            $obj = new Wp_Travel_Engine_Functions();
                                            echo '<span class="price-holder"><span>'.esc_attr($currency).esc_attr( $obj->wp_travel_engine_price_format($cost) ).'</span></span>';
                                        }
                                        else{ 
                                            if( $prev_cost!='' )
                                            {
                                                $obj = new Wp_Travel_Engine_Functions();
                                                echo '<span class="price-holder"><span>'.esc_attr($currency).esc_attr( $obj->wp_travel_engine_price_format($prev_cost) ).'</span></span>';
                                            }
                                        }
                                        ?>
							</div>
							<div class="text-holder">
								<h3 class="entry-title"><a href="<?php echo esc_url( get_the_permalink() );?>"><?php the_title();?></a></h3>
								<?php
                                if( isset( $wp_travel_engine_setting['trip_duration'] ) && $wp_travel_engine_setting['trip_duration']!='' )
                                { ?>
                                    <div class="meta-info">
                                        <span class="time">
                                            <i class="fa fa-clock-o"></i>
                                            <?php echo esc_attr($wp_travel_engine_setting['trip_duration']); if($wp_travel_engine_setting['trip_duration']>1){ _e(' days','wp-travel-engine-trip-search');} else{ _e(' day','wp-travel-engine-trip-search'); }
                                            ?>
                                        </span>
                                    </div>
                                <?php } ?>
                                <div class="btn-holder">
                                    <a href="<?php echo esc_url( get_the_permalink() );?>" class="btn-more"><?php _e('View Detail','wp-travel-engine-trip-search');?></a>
                                </div>
							</div>
				    	</div>
					<?php
					}
					?>
				</div>
			<?php
		    $default_posts_per_page = get_option( 'posts_per_page' );
		   	if( $query->found_posts > $default_posts_per_page )
            {
		   		echo '<span data-id="'.$query->found_posts.'"><a data-id="'.$default_posts_per_page.'" href="#" class="load-more-search">'.__('Load More','wp-travel-engine-trip-search').'</a></span>';
		   	}
		   	?>
			</div>
		   	<?php
		}
		$output = ob_get_contents();
        ob_end_clean();
        echo $output;
        wp_reset_query();
        exit(); 	
	}

	function wte_show_ajax_result_load()
	{
		$nonce = wp_create_nonce('search-nonce');
		if(isset($_REQUEST['nonce']) && wp_verify_nonce( $_REQUEST['nonce'], "search-nonce" ) )
		{			
  			$msg = __("No results found!","wp-travel-engine-trip-search");

			if( !empty( $_REQUEST["result"]["cat"] ) ) {
				foreach ( $_REQUEST["result"]["cat"] as $key => $value ) {
					$term = get_term_by('slug', $value, 'trip_types');
			    	$cat[] = $term->term_id;
				}
			}

			if( !empty( $_REQUEST["result"]["budget"] ) ) {
			    $budget = $_REQUEST["result"]["budget"];
			}

			if( !empty( $_REQUEST["result"]["activities"] ) ) {
			    foreach ( $_REQUEST["result"]["activities"] as $key => $value ) {
					$term = get_term_by('slug', $value, 'activities');
			    	$activities[] = $term->term_id;
				}
			}

			if( !empty( $_REQUEST["result"]["destination"] ) ) {
			    foreach ( $_REQUEST["result"]["destination"] as $key => $value ) {
					$term = get_term_by('slug', $value, 'destination');
			    	$destination[] = $term->term_id;
				}
			}

			if( !empty( $_REQUEST["result"]["duration"] ) ) {
			    $duration = $_REQUEST["result"]["duration"];
			}

			if( !empty( $_REQUEST["cost"] ) ) {
			    $cost = $_REQUEST["cost"];
			}
            $default_posts_per_page = get_option( 'posts_per_page' );
			$page = ( $_REQUEST['offset'] ) ? absint( $_REQUEST['offset'] ) : 0;
			// $page = $page + $page;
			// Query arguments.
			$args = array(
			            'post_type'      				=> 'trip',
			            'posts_per_page' 				=> $default_posts_per_page,
			            'wpse_search_or_tax_query'      => true,
			            'offset'						=> $page
			        );

			$taxquery = array();
  			
			if( !empty( $_REQUEST["result"]["cat"] ) && $_REQUEST["result"]["cat"]!= '-1'  ){
			    array_push($taxquery,array(
			            'taxonomy' => 'trip_types',
			            'field'    => 'term_id',
			            'terms'    => $cat,
			            'include_children' => false,
			        ));
			}

			if(!empty($_REQUEST["result"]["activities"]) && $_REQUEST["result"]["activities"]!='-1' ) {
			    array_push($taxquery,array(
			            'taxonomy' 	=> 'activities',
			            'field' 	=> 'term_id',
			            'terms' 	=> $activities,
			            'include_children' => false,
			        ));
			}

			if(!empty($_REQUEST["result"]["destination"]) && $_REQUEST["result"]["destination"]!='-1' ) {
			    array_push($taxquery,array(
			            'taxonomy' 	=> 'destination',
			            'field' 	=> 'term_id',
			            'terms' 	=> $destination,
			            'include_children' => false,
			        ));
			}

			if(!empty($taxquery)){
				$args['tax_query']['relation'] = 'AND';
				$args['tax_query'] = $taxquery;
			}
			$meta_query = array();

			$start_cost = (int)$_REQUEST['mincost'];
			$end_cost = (int)$_REQUEST['maxcost'];
			$meta_query[] = array(
			    array(
		            'key' => 'wp_travel_engine_setting_trip_price',
		            'value' => array($start_cost,$end_cost),
		            'compare' => 'BETWEEN',
					'type'	=> 'NUMERIC'

		        )
			);
		    
			$start_dur = (int)$_REQUEST['mindur'];
			$end_dur = (int)$_REQUEST['maxdur'];
			$meta_query[] = array(
			    array(
		            'key' => 'wp_travel_engine_setting_trip_duration',
		            'value' => array($start_dur,$end_dur),
		            'compare' => 'BETWEEN',
					'type'	=> 'NUMERIC'

		        )
			);

			if(!empty($meta_query)){
				 	$args['meta_query'] = $meta_query;
			}
		    $query = new WP_Query($args);
		    ob_start();
	    	global $post;
			while ( $query->have_posts() ) {
				$query->the_post(); 
    			$wp_travel_engine_setting = get_post_meta( $post->ID,'wp_travel_engine_setting',true );
                $wp_travel_engine_setting_option_setting = get_option( 'wp_travel_engine_settings', true );
    			?>
				<div class="col">
            		<div class="img-holder">
		                <a href="<?php the_permalink(); ?>" class="trip-post-thumbnail">
							<?php 
							$feat_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'trip-thumb-size' ); 
							if( isset($feat_image_url[0]) && $feat_image_url[0]!='' )
							{ ?>
								<img src="<?php echo esc_url( $feat_image_url[0] );?>">

							<?php }  else{
                                       echo '<img src="'.esc_url(  WP_TRAVEL_ENGINE_IMG_URL . '/public/css/images/trip-listing-fallback.jpg' ).'">';
                                    }?>
						</a>
						   <?php
                            $code = 'USD';
                            if( isset($wp_travel_engine_setting_option_setting['currency_code']) && $wp_travel_engine_setting_option_setting['currency_code']!='')
                            {
                                $code = esc_attr( $wp_travel_engine_setting_option_setting['currency_code'] );
                            }
                            $obj = new Wp_Travel_Engine_Functions();
                            $currency = $obj->wp_travel_engine_currencies_symbol( $code );
                            $cost = isset( $wp_travel_engine_setting['trip_price'] ) ? $wp_travel_engine_setting['trip_price']: '';
                            
                            $prev_cost = isset( $wp_travel_engine_setting['trip_prev_price'] ) ? $wp_travel_engine_setting['trip_prev_price']: '';

                                $code = 'USD';
                                if( isset( $wp_travel_engine_setting_option_setting['currency_code'] ) && $wp_travel_engine_setting_option_setting['currency_code']!= '' )
                                {
                                    $code = $wp_travel_engine_setting_option_setting['currency_code'];
                                } 
                                $obj = new Wp_Travel_Engine_Functions();
                                $currency = $obj->wp_travel_engine_currencies_symbol( $code );
                                $prev_cost = isset($wp_travel_engine_setting['trip_prev_price']) ? $wp_travel_engine_setting['trip_prev_price']: '';
                                if( $cost!='' && isset($wp_travel_engine_setting['sale']) )
                                {
                                    $obj = new Wp_Travel_Engine_Functions();
                                    echo '<span class="price-holder"><span>'.esc_attr($currency).esc_attr( $obj->wp_travel_engine_price_format($cost) ).'</span></span>';
                                }
                                else{ 
                                    if( $prev_cost!='' )
                                    {
                                        $obj = new Wp_Travel_Engine_Functions();
                                        echo '<span class="price-holder"><span>'.esc_attr($currency).esc_attr( $obj->wp_travel_engine_price_format($prev_cost) ).'</span></span>';
                                    }
                                }
                                ?>
					</div>
					<div class="text-holder">
						<h3 class="entry-title"><a href="<?php echo esc_url( get_the_permalink() );?>"><?php the_title();?></a></h3>
						<?php
                        if( isset( $wp_travel_engine_setting['trip_duration'] ) && $wp_travel_engine_setting['trip_duration']!='' )
                        { ?>
                            <div class="meta-info">
                                <span class="time">
                                    <i class="fa fa-clock-o"></i>
                                    <?php echo esc_attr($wp_travel_engine_setting['trip_duration']); if($wp_travel_engine_setting['trip_duration']>1){ _e(' days','wp-travel-engine-trip-search');} else{ _e(' day','wp-travel-engine-trip-search'); }
                                    ?>
                                </span>
                            </div>
                        <?php } ?>
                        <div class="btn-holder">
                            <a href="<?php echo esc_url( get_the_permalink() );?>" class="btn-more"><?php _e('View Detail','wp-travel-engine-trip-search');?></a>
                        </div>
					</div>
		    	</div>
			<?php
			}		
		}
		$output = ob_get_contents();
        ob_end_clean();
        echo $output;
        wp_reset_query();
        exit(); 	
	}

	function wte_show_ajax_archives_result()
	{
		$nonce = wp_create_nonce('search-nonce');
		if(isset($_REQUEST['nonce']) && wp_verify_nonce( $_REQUEST['nonce'], "search-nonce" ) )
		{			
  			$msg = __("No results found!","wp-travel-engine-trip-search");
            
            $default_posts_per_page = get_option( 'posts_per_page' );

			$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;

			// Query arguments.
			$args = array(
			            'post_type'      				=> 'trip',
			            'posts_per_page' 				=> $default_posts_per_page,
			            'wpse_search_or_tax_query'      => true,
			        );

			$taxquery = array();
  			
			if( !empty( $_REQUEST['cat'] ) && $_REQUEST['cat']!= '-1'  ){
			    array_push($taxquery,array(
			            'taxonomy' => 'trip_types',
			            'field'    => 'slug',
			            'terms'    => $_REQUEST['cat'],
			            'include_children' => false,
			        ));
			}

			if(!empty($_REQUEST['activities']) && $_REQUEST['activities']!='-1' ) {
			    array_push($taxquery,array(
			            'taxonomy' 	=> 'activities',
			            'field' 	=> 'slug',
			            'terms' 	=> $_REQUEST['activities'],
			            'include_children' => false,
			        ));
			}

			if(!empty($_REQUEST['destination']) && $_REQUEST['destination']!='-1' ) {
			    array_push($taxquery,array(
			            'taxonomy' 	=> 'destination',
			            'field' 	=> 'slug',
			            'terms' 	=> $_REQUEST['destination'],
			            'include_children' => false,
			        ));
			}

			if(!empty($taxquery)){
				$args['tax_query']['relation'] = 'AND';
				$args['tax_query'] = $taxquery;
			}

			$meta_query = array();

			if(isset($_REQUEST['mincost']) && isset($_REQUEST['maxcost']))
			{
				$start_cost = (int)$_REQUEST['mincost'];
				$end_cost = (int)$_REQUEST['maxcost'];
				$meta_query[] = array(
				    array(
			            'key' => 'wp_travel_engine_setting_trip_price',
			            'value' => array($start_cost,$end_cost),
			            'compare' => 'BETWEEN',
						'type'	=> 'NUMERIC'

			        )
				);
			}
		    
		    if(isset($_REQUEST['mindur']) && isset($_REQUEST['maxdur']))
			{
				$start_dur = (int)$_REQUEST['mindur'];
				$end_dur = (int)$_REQUEST['maxdur'];
				$meta_query[] = array(
				    array(
			            'key' => 'wp_travel_engine_setting_trip_duration',
			            'value' => array($start_dur,$end_dur),
			            'compare' => 'BETWEEN',
						'type'	=> 'NUMERIC'

			        )
				);
			}

			if(!empty($meta_query)){
				 	$args['meta_query'] = $meta_query;
			}
		    $query = new WP_Query($args);
		    ob_start(); ?>
			<?php echo ($query->found_posts > 0) ? '<div class="wte-advanced-search-wrap"><h3 class="foundPosts">' . $query->found_posts. ' trip(s) found:'.'</h3>' : '<h3 class="foundPosts">'.apply_filters( 'no_result_found_message',$msg ).'</h3>'; ?>
		    <div class="grid">
			   	<?php
			    	global $post;
					while ( $query->have_posts() ) {
						$query->the_post(); 
		    			$wp_travel_engine_setting = get_post_meta( $post->ID,'wp_travel_engine_setting',true );
                        $wp_travel_engine_setting_option_setting = get_option( 'wp_travel_engine_settings', true );
		    			?>
						<div class="col">
                    		<div class="img-holder">
				                <a href="<?php the_permalink(); ?>" class="trip-post-thumbnail">
									<?php 
									$feat_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'trip-thumb-size' ); 
									if( isset($feat_image_url[0]) && $feat_image_url[0]!='' )
									{ ?>
        								<img src="<?php echo esc_url( $feat_image_url[0] );?>">
        
        							<?php } else{
                                               echo '<img src="'.esc_url(  WP_TRAVEL_ENGINE_IMG_URL . '/public/css/images/trip-listing-fallback.jpg' ).'">';
                                            }
                                            ?>
								</a>
							</div>
							<div class="text-holder">
								<h3 class="entry-title"><a href="<?php echo esc_url( get_the_permalink() );?>"><?php the_title();?></a></h3>
								<?php
                                if( isset( $wp_travel_engine_setting['trip_duration'] ) && $wp_travel_engine_setting['trip_duration']!='' )
                                { ?>
                                    <div class="meta-info">
                                        <span class="time">
                                            <i class="fa fa-clock-o"></i>
                                            <?php echo esc_attr($wp_travel_engine_setting['trip_duration']); if($wp_travel_engine_setting['trip_duration']>1){ _e(' days','wp-travel-engine-trip-search');} else{ _e(' day','wp-travel-engine-trip-search'); }
                                            ?>
                                        </span>
                                    </div>
                                <?php } ?>
                                <div class="btn-holder">
                                    <a href="<?php echo esc_url( get_the_permalink() );?>" class="btn-more"><?php _e('View Detail','wp-travel-engine-trip-search');?></a>
                                </div>
							</div>
				    	</div>
				    <?php
					}
					?>
				<input type="hidden" name="search-nonce" data-id="1" id="search-nonce" value="<?php echo $nonce; ?>">
				<div id="loader" style="display: none">
		        <div class="table">
			    <div class="table-row">
			    <div class="table-cell">
			    <i class="fa fa-spinner fa-spin" aria-hidden="true"></i></div></div></div></div>
			</div>
		</div>
		<?php 
		}
		$output = ob_get_contents();
        ob_end_clean();
        echo $output; 
        exit();		
	}
}
new Wte_Advanced_Search_Template;
