<?php
// Register and load the widget
function wte_advanced_search_load_widget() {
    register_widget( 'wte_advanced_search_widget' );
}
add_action( 'widgets_init', 'wte_advanced_search_load_widget' );

// Creating the widget 
class Wte_Advanced_Search_Widget extends WP_Widget {

    function __construct() {
        parent::__construct(

        // Base ID of your widget
        'wte_advanced_search_widget', 

        // Widget name will appear in UI
        __('WTE Advanced Search Widget', 'wp-travel-engine-trip-search'), 

        // Widget description
        array( 'description' => __( 'WTE Advanced Search Widget for Trips', 'wp-travel-engine-trip-search' ), ) 
        );
    }

    // Creating widget front-end

    public function widget( $args, $instance ) {
        $title = apply_filters( 'widget_title', $instance['title'] );

        // before and after widget arguments are defined by themes
        echo $args['before_widget'];
        if ( ! empty( $title ) )
        echo $args['before_title'] . $title . $args['after_title'];

        $options = get_option( 'wp_travel_engine_settings', array() );
        $pid = '';
        if( isset( $options['pages']['search'] ) )
            $pid = $options['pages']['search'];
        $nonce = wp_create_nonce('search-nonce');
        ?>
        <form method="get" action='<?php echo esc_url(get_permalink($pid));?>' id="wte-advanced-search-form">
            <input type="hidden" name="search-nonce" value="<?php echo $nonce;?>">
            <?php 
            $categories = get_categories('taxonomy=trip_types');

            $select = "<div class='advanced-search-field'><select name='cat' id='cat' class='postform'>";
            $select.= "<option value='-1'>Select type</option>";
              
            foreach($categories as $category){
                if($category->count > 0){
                    $select.= "<option value='".$category->slug."'>".$category->name."</option>";
                }
            }
              
            $select.= "</select></div>";
              
            echo $select;

            $categories = get_categories('taxonomy=activities');

            $select = "<div class='advanced-search-field'><select name='activities' id='activities' class='postform'>";
            $select.= "<option value='-1'>Select activity</option>";
              
            foreach($categories as $category){
                if($category->count > 0){
                    $select.= "<option value='".$category->slug."'>".$category->name."</option>";
                }
            }
              
            $select.= "</select></div>";
              
            echo $select;


            $categories = get_categories('taxonomy=destination');

            $select = "<div class='advanced-search-field'><select name='destination' id='destination' class='postform'>";
            $select.= "<option value='-1'>Select destination</option>";
              
            foreach($categories as $category){
                if($category->count > 0){
                    $select.= "<option value='".$category->slug."'>".$category->name."</option>";
                }
            }
              
            $select.= "</select></div>";
              
            echo $select;
            ?>

            <div class='advanced-search-field-submit'><input type="submit" name="search" value="<?php $search = apply_filters('wte_search_label', 'Search'); _e( $search ,'wp-travel-engine-trip-search');?>"></div>
        </form>
        <?php
        // This is where you run the code and display the output
        echo $args['after_widget'];
    }
            
    // Widget Backend 
    public function form( $instance ) {
        if ( isset( $instance[ 'title' ] ) ) {
        $title = $instance[ 'title' ];
        }
        else {
        $title = __( 'New title', 'wp-travel-engine-trip-search' );
        }
        // Widget admin form
        ?>
        <p>
        <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'wp-travel-engine-trip-search' ); ?></label> 
        <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
    <?php 
    }
    
    // Updating widget replacing old instances with new
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        return $instance;
    }
} // Class wpb_widget ends here