<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Advanced_Search
 * @subpackage Wte_Advanced_Search/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wte_Advanced_Search
 * @subpackage Wte_Advanced_Search/includes
 * @author     WP Travel Engine <wptravelengine.com>
 */
class Wte_Advanced_Search_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		$arr = array();
		$options = get_option( 'wp_travel_engine_settings', array() );
		if( isset( $options['pages']['search'] ) )
		{
			return;
		}
		$title = 'Trip Search Result';
		$shortcode = '[WTE_Trip_Search]';
		// Check if this page already exists, with shortcode
		$existing_page = get_page_by_title( $title );

		if ( $existing_page!='' && 'page' === $existing_page->post_type)  {
			$content = $existing_page->post_content;
			if( has_shortcode($content,$shortcode)){
				return;
			}
		}
		else{
			$new_page = array(
			'post_title'    => $title,
			'post_content'  => $shortcode,
			'post_status'   => 'publish',
			'post_type'     => 'page',
			);
			$post_id = wp_insert_post( $new_page );
			if( !isset($options['pages']['search']) || $options['pages']['search'] == '' )
			{
				$arr['pages']['search'] = $post_id;
				$enquiry_page = array_merge_recursive( $options, $arr );
				update_option ( 'wp_travel_engine_settings', $enquiry_page );
			}
		}
	}
}
