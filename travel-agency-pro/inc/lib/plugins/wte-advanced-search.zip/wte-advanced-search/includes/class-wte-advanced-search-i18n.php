<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://www.wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Advanced_Search
 * @subpackage Wte_Advanced_Search/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Wte_Advanced_Search
 * @subpackage Wte_Advanced_Search/includes
 * @author     WP Travel Engine <wptravelengine.com>
 */
class Wte_Advanced_Search_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'wte-advanced-search',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
